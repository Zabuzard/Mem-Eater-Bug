# Mem-Eater-Bug
API that provides various methods for memory manipulation using JNA.

The available documentation can be found in [our wiki](https://github.com/ZabuzaW/Mem-Eater-Bug/wiki).
